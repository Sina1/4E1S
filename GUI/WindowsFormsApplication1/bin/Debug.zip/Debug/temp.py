import time

print "Generating SLD"

for i in range(1,3):
    print i," percent completed         \r",
    time.sleep(1)

print "JUST KIDDING!!"
time.sleep(3)
    
